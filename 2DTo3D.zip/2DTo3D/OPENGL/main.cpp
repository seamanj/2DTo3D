

#include "AntTweakBar.h"


#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <iostream>
#include <Eigen/Dense>
#include <Windows.h>

#if defined(_WIN32) || defined(_WIN64)
//  MiniGLUT.h is provided to avoid the need of having GLUT installed to 
//  recompile this example. Do not use it in your own programs, better
//  install and use the actual GLUT library SDK.
//#   define USE_MINI_GLUT
#endif

#if defined(USE_MINI_GLUT)
#   include "MiniGLUT.h"
#elif defined(_MACOSX)
#   include <GLUT/glut.h>
#else
#   include <GL/glut.h>
#endif

#include "GLM.h"
#include "glm\glm.hpp"
#include "glm\gtc\matrix_transform.hpp"
#include "glm\gtc\type_ptr.hpp"




// This example displays one of the following shapes

// Shapes scale
float g_Zoom = 1.0f;
// Shape orientation (stored as a quaternion)
float g_Rotation[] = { 0.0f, 0.0f, 0.0f, 1.0f };
// Auto rotate
int g_AutoRotate = 0;
int g_RotateTime = 0;
float g_RotateStart[] = { 0.0f, 0.0f, 0.0f, 1.0f };
// Shapes material
float g_MatAmbient[] = { 0.5f, 0.0f, 0.0f, 1.0f };
float g_MatDiffuse[] = { 1.0f, 1.0f, 0.0f, 1.0f };
// Light parameter
float g_LightMultiplier = 1.0f;
float g_LightDirection[] = { -0.57735f, -0.57735f, -0.57735f };
// Axis parameter

float g_AxisDirection[] = {0.0f, 1.0f, 0.0f};


float g_cameraAngleX = 0.0f, g_cameraAngleY = 0.0f;
float g_mouseX = 0.0f, g_mouseY = 0.0f;
bool g_mouseLeftDown = false;

float g_screenWidth=1024;
float g_screenHeight=768;

glm::mat4 g_projection=glm::mat4(1);
glm::mat4 g_modelview=glm::mat4(1);
glm::mat4 g_world=glm::mat4(1);
glm::mat4 g_view=glm::mat4(1);
glm::mat4 g_mvp=glm::mat4(1);
glm::mat4 Rx = glm::mat4(1);
//float g_lastAngle = 0.0f;
float g_accuAngle = 0.0f;
float g_currentlyRotatedAngle = 0.0f;
Eigen::Matrix<float, 3, 24> g_3DCuboidPositionOriginal;
Eigen::Matrix<float, 3, 24> g_3DCuboidPositionCurrent;


// Routine to set a quaternion from a rotation axis and angle
// ( input axis = float[3] angle = float  output: quat = float[4] )
void SetQuaternionFromAxisAngle(const float *axis, float angle, float *quat)
{
    float sina2, norm;
    sina2 = (float)sin(0.5f * angle);
    norm = (float)sqrt(axis[0]*axis[0] + axis[1]*axis[1] + axis[2]*axis[2]);
    quat[0] = sina2 * axis[0] / norm;
    quat[1] = sina2 * axis[1] / norm;
    quat[2] = sina2 * axis[2] / norm;
    quat[3] = (float)cos(0.5f * angle);
}


// Routine to convert a quaternion to a 4x4 matrix
// ( input: quat = float[4]  output: mat = float[4*4] )
void ConvertQuaternionToMatrix(const float *quat, float *mat)
{
    float yy2 = 2.0f * quat[1] * quat[1];
    float xy2 = 2.0f * quat[0] * quat[1];
    float xz2 = 2.0f * quat[0] * quat[2];
    float yz2 = 2.0f * quat[1] * quat[2];
    float zz2 = 2.0f * quat[2] * quat[2];
    float wz2 = 2.0f * quat[3] * quat[2];
    float wy2 = 2.0f * quat[3] * quat[1];
    float wx2 = 2.0f * quat[3] * quat[0];
    float xx2 = 2.0f * quat[0] * quat[0];
    mat[0*4+0] = - yy2 - zz2 + 1.0f;
    mat[0*4+1] = xy2 + wz2;
    mat[0*4+2] = xz2 - wy2;
    mat[0*4+3] = 0;
    mat[1*4+0] = xy2 - wz2;
    mat[1*4+1] = - xx2 - zz2 + 1.0f;
    mat[1*4+2] = yz2 + wx2;
    mat[1*4+3] = 0;
    mat[2*4+0] = xz2 + wy2;
    mat[2*4+1] = yz2 - wx2;
    mat[2*4+2] = - xx2 - yy2 + 1.0f;
    mat[2*4+3] = 0;
    mat[3*4+0] = mat[3*4+1] = mat[3*4+2] = 0;
    mat[3*4+3] = 1;
}


// Routine to multiply 2 quaternions (ie, compose rotations)
// ( input q1 = float[4] q2 = float[4]  output: qout = float[4] )
void MultiplyQuaternions(const float *q1, const float *q2, float *qout)
{
    float qr[4];
	qr[0] = q1[3]*q2[0] + q1[0]*q2[3] + q1[1]*q2[2] - q1[2]*q2[1];
	qr[1] = q1[3]*q2[1] + q1[1]*q2[3] + q1[2]*q2[0] - q1[0]*q2[2];
	qr[2] = q1[3]*q2[2] + q1[2]*q2[3] + q1[0]*q2[1] - q1[1]*q2[0];
	qr[3]  = q1[3]*q2[3] - (q1[0]*q2[0] + q1[1]*q2[1] + q1[2]*q2[2]);
    qout[0] = qr[0]; qout[1] = qr[1]; qout[2] = qr[2]; qout[3] = qr[3];
}


// Return elapsed time in milliseconds
int GetTimeMs()
{
#if !defined(_WIN32)
    return glutGet(GLUT_ELAPSED_TIME);
#else
    // glutGet(GLUT_ELAPSED_TIME) seems buggy on Windows
    return (int)GetTickCount(); 
#endif
}


void Update3DCuboidPosition(float *mat)
{
	Eigen::Map<Eigen::Matrix<float, 4, 4>> mapMatrix(mat);
	//std::cout << mapMatrix << std::endl;
	g_3DCuboidPositionCurrent = mapMatrix.block<3,3>(0,0) * g_3DCuboidPositionOriginal;
	//std::cout << g_3DCuboidPositionCurrent << std::endl;
}

void Draw2DCuboid()
{
	glBegin(GL_LINES);
	for(int i = 1; i < g_3DCuboidPositionCurrent.cols(); ++i)
	{
		if( i % 4 != 0)
		{
			glVertex3f(g_3DCuboidPositionCurrent.col(i - 1)(0), g_3DCuboidPositionCurrent.col(i - 1)(1), -10);
			glVertex3f(g_3DCuboidPositionCurrent.col(i)(0), g_3DCuboidPositionCurrent.col(i)(1), -10);
		}
		else
		{
			glVertex3f(g_3DCuboidPositionCurrent.col(i - 4)(0), g_3DCuboidPositionCurrent.col(i - 4)(1), -10);
			glVertex3f(g_3DCuboidPositionCurrent.col(i - 1)(0), g_3DCuboidPositionCurrent.col(i - 1)(1), -10);
		}
	}
	glEnd();
}

void Output3DCuboidPosition()
{
	int order[8] = {0, 1, 2, 3, 4, 7, 6, 5};
	for(int i = 0; i < 8; ++i)
	{
		std::cout << char( 'A' + order[i]) << "(3D) : "  << g_3DCuboidPositionCurrent.col(i).transpose() << std::endl;
	}
	
}


void Output2DCuboidPosition()
{
	int order[8] = {0, 1, 2, 3, 4, 7, 6, 5};
	for(int i = 0; i < 8; ++i)
	{
		std::cout << char( 'A' + order[i]) << "(2D) : "  << g_3DCuboidPositionCurrent.col(i).head(2).transpose()  << std::endl;
	}
	
}

void Draw3DCuboid()
{
	glBegin(GL_QUADS);
	for(int i = 0; i < g_3DCuboidPositionCurrent.cols(); ++i)
	{
		if( i % 4 == 0)
		{
			Eigen::Vector3f vec1 = g_3DCuboidPositionCurrent.col(i) - g_3DCuboidPositionCurrent.col(i + 1);
			Eigen::Vector3f vec2 = g_3DCuboidPositionCurrent.col(i + 2) - g_3DCuboidPositionCurrent.col(i + 1);
			Eigen::Vector3f nor = vec2.cross(vec1);
			glNormal3f(nor(0), nor(1), nor(2));

		}

		glVertex3f(g_3DCuboidPositionCurrent.col(i)(0), g_3DCuboidPositionCurrent.col(i)(1), g_3DCuboidPositionCurrent.col(i)(2));
	}
	glEnd();
}
void DrawLines()
{
	glDisable(GL_LIGHTING);
	glBegin(GL_LINES);
	glColor3f(1.0f, 0.0f, 0.0f);
	for(int i = 0; i < g_3DCuboidPositionCurrent.cols(); ++i)
	{
		glVertex3f(g_3DCuboidPositionCurrent.col(i)(0), g_3DCuboidPositionCurrent.col(i)(1), g_3DCuboidPositionCurrent.col(i)(2));
		glVertex3f(g_3DCuboidPositionCurrent.col(i)(0), g_3DCuboidPositionCurrent.col(i)(1), -10);
	}
	glColor3f(1.0f, 1.0f, 1.0f);
	glEnd();
	glEnable(GL_LIGHTING);
}

void SetMatrix();
// Callback function called by GLUT to render screen
void Display(void)
{
    float v[4]; // will be used to set light parameters
    float mat[4*4]; // rotation matrix

    // Clear frame buffer
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glEnable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_NORMALIZE);

    // Set light
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    v[0] = v[1] = v[2] = g_LightMultiplier*0.4f; v[3] = 1.0f;
    glLightfv(GL_LIGHT0, GL_AMBIENT, v);
    v[0] = v[1] = v[2] = g_LightMultiplier*0.8f; v[3] = 1.0f;
    glLightfv(GL_LIGHT0, GL_DIFFUSE, v);
    v[0] = -g_LightDirection[0]; v[1] = -g_LightDirection[1]; v[2] = -g_LightDirection[2]; v[3] = 0.0f;
    glLightfv(GL_LIGHT0, GL_POSITION, v);

    // Set material
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, g_MatAmbient);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, g_MatDiffuse);


	// Set matrix

	SetMatrix();

    // Rotate and draw shape
    glPushMatrix();
    //glTranslatef(0.5f, -0.3f, 0.0f);
	
    if( g_AutoRotate ) 
    {
//         float axis[3] = { 0, 1, 0 };
         g_currentlyRotatedAngle = (float)(GetTimeMs()-g_RotateTime)/1000.0f;
//         float quat[4];
//         SetQuaternionFromAxisAngle(axis, angle, quat);
//         MultiplyQuaternions(g_RotateStart, quat, g_Rotation);

		Rx	= glm::rotate(glm::mat4(1.0f),  g_accuAngle + g_currentlyRotatedAngle, glm::make_vec3(g_AxisDirection));
		
    }
	else
	{
		Rx = glm::rotate(glm::mat4(1.0f),  g_accuAngle, glm::make_vec3(g_AxisDirection));
	}
    
	Update3DCuboidPosition((float*)glm::value_ptr(Rx));
    //glMultMatrixf(mat);
    //glScalef(g_Zoom, g_Zoom, g_Zoom);
	Draw3DCuboid();
	if( g_AutoRotate )
		Output3DCuboidPosition();
	DrawLines();
	Draw2DCuboid();
	if( g_AutoRotate )
		Output2DCuboidPosition();
    //glCallList(1);
    glPopMatrix();

	glDisable(GL_LIGHTING);
	glCallList(2);
	glEnable(GL_LIGHTING);
    // Draw tweak bars
    TwDraw();

    // Present frame buffer
    glutSwapBuffers();

    // Recall Display at next frame
    glutPostRedisplay();
}
void TransToArray(GLdouble* trans,glm::mat4 mat)  //GLM->GL
{
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
		{
			int index=i*4+j;
			float temp=mat[i][j];
			trans[index]=mat[i][j];
		}
}

void SetMatrix()
{
	g_projection = glm::perspective(45.0f, (float)g_screenWidth / g_screenHeight, 0.1f, 50.0f);
	 //m_view=glm::lookAt(g_camerapos,g_camerapos+glm::vec3(0,0,-1),glm::vec3(0,1,0));
	glm::mat4 T		= glm::translate(glm::mat4(1.0f),glm::vec3(0, 0, g_Zoom - 10));
	glm::mat4 Rx	= glm::rotate(T,  g_cameraAngleX, glm::vec3(1.0f, 0.0f, 0.0f));
	g_world    = glm::rotate(Rx, g_cameraAngleY, glm::vec3(0.0f, 1.0f, 0.0f));
	////g_world    = glm::translate(glm::mat4(1.0f),glm::vec3(0, 0, cameraDistance-5));
	g_modelview=g_world;
	g_mvp = g_projection*g_world;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	GLdouble tempmat[16];
	TransToArray(tempmat,g_mvp);
	glMultMatrixd(tempmat);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

// Callback function called by GLUT when window size changes
void Reshape(int width, int height)
{
	if ( width != 0 && height != 0)
	{
		g_screenWidth = width;
		g_screenHeight = height;
	}
		SetMatrix();
    // Set OpenGL viewport and camera
//     glViewport(0, 0, width, height);
//     glMatrixMode(GL_PROJECTION);
//     glLoadIdentity();
//     gluPerspective(40, (double)width/height, 1, 100);
//     glMatrixMode(GL_MODELVIEW);
//     glLoadIdentity();
//     gluLookAt(0,20,20, 0,0,0, 0,0,-1);
//     glTranslatef(0, 0.6f, -1);

    // Send the new window size to AntTweakBar
    TwWindowSize(width, height);
}


// Function called at exit
void Terminate(void)
{ 
    glDeleteLists(1, 2);

    TwTerminate();
}


//  Callback function called when the 'AutoRotate' variable value of the tweak bar has changed
void TW_CALL SetAutoRotateCB(const void *value, void *clientData)
{
    (void)clientData; // unused

    g_AutoRotate = *(const int *)value; // copy value to g_AutoRotate
    if( g_AutoRotate!=0 ) 
    {
        // init rotation
        g_RotateTime = GetTimeMs();
        // make Rotation variable read-only
        //TwDefine(" TweakBar/ObjRotation readonly ");
    }
    else
	{
		g_accuAngle += g_currentlyRotatedAngle;
        // make Rotation variable read-write
        //TwDefine(" TweakBar/ObjRotation readwrite ");
	}
}


//  Callback function called by the tweak bar to get the 'AutoRotate' value
void TW_CALL GetAutoRotateCB(void *value, void *clientData)
{
    (void)clientData; // unused
    *(int *)value = g_AutoRotate; // copy g_AutoRotate to value

}

void InitCuboidPosition()
{
	g_3DCuboidPositionOriginal << -1.0f, -1.0f, 1.0f, 1.0f,     -1.0f, 1.0f, 1.0f, -1.0f,     -1.0f, -1.0f, -1.0f, -1.0f,    1.0f, 1.0f, 1.0f, 1.0f,     -1.0f, 1.0f, 1.0f, -1.0f,     -1.0f, -1.0f, 1.0f, 1.0f,
		                  2.0f, -2.0f, -2.0f, 2.0f,     2.0f, 2.0f, -2.0f, -2.0f,     2.0f, 2.0f, -2.0f, -2.0f,     -2.0f, -2.0f, 2.0f, 2.0f,    2.0f, 2.0f, 2.0f, 2.0f ,      -2.0f, -2.0f, -2.0f, -2.0f,
						  3.0f, 3.0f, 3.0f, 3.0f,      -3.0f, -3.0f, -3.0f, -3.0f,    3.0f, -3.0f, -3.0f, 3.0f,     3.0f, -3.0f, -3.0f, 3.0f,    3.0f, 3.0f, -3.0f, -3.0f,     3.0f, -3.0f, -3.0f, 3.0f;
	//std::cout << g_3DCuboidPosition << std::endl;
}

void MouseMotionCB(int x, int y)
{
	if (!TwEventMouseMotionGLUT(x, y))
	{
		g_cameraAngleY += (x - g_mouseX)/100;
		g_cameraAngleX += (y - g_mouseY)/100;
		g_mouseX = x;
		g_mouseY = y;
	}
}

void MouseCB(int button, int state, int x, int y)
{
	g_mouseX = x;
	g_mouseY = y;

    if (!TwEventMouseButtonGLUT(button, state, x, y))
	{
		switch(state)
		{
		case GLUT_DOWN:
			if (glutGetModifiers() == GLUT_LEFT_BUTTON)
			{
				g_mouseLeftDown = true;
			}
			break;
		case GLUT_UP:
			if (glutGetModifiers() == GLUT_LEFT_BUTTON)
			{
				g_mouseLeftDown = false;
			}
			break;
		}
	}
}

// Main
int main(int argc, char *argv[])
{
    TwBar *bar; // Pointer to the tweak bar
    float axis[] = { 0.0f, 1.0f, 0.0f }; // initial model rotation
    float angle = 0.0f;

	// Initialize cuboid points position
	InitCuboidPosition();

    // Initialize GLUT
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(g_screenWidth, g_screenHeight);
    glutCreateWindow("AntTweakBar simple example using GLUT");
    glutCreateMenu(NULL);

    // Set GLUT callbacks
    glutDisplayFunc(Display);
    glutReshapeFunc(Reshape);
    atexit(Terminate);  // Called after glutMainLoop ends

    // Initialize AntTweakBar
    TwInit(TW_OPENGL, NULL);

    // Set GLUT event callbacks
    // - Directly redirect GLUT mouse button events to AntTweakBar
    //glutMouseFunc((GLUTmousebuttonfun)TwEventMouseButtonGLUT);
    // - Directly redirect GLUT mouse motion events to AntTweakBar
    //glutMotionFunc((GLUTmousemotionfun)TwEventMouseMotionGLUT);

	glutMouseFunc(MouseCB);
	glutMotionFunc(MouseMotionCB);

    // - Directly redirect GLUT mouse "passive" motion events to AntTweakBar (same as MouseMotion)
    glutPassiveMotionFunc((GLUTmousemotionfun)TwEventMouseMotionGLUT);
    // - Directly redirect GLUT key events to AntTweakBar
    glutKeyboardFunc((GLUTkeyboardfun)TwEventKeyboardGLUT);
    // - Directly redirect GLUT special key events to AntTweakBar
    glutSpecialFunc((GLUTspecialfun)TwEventSpecialGLUT);
    // - Send 'glutGetModifers' function pointer to AntTweakBar;
    //   required because the GLUT key event functions do not report key modifiers states.
    TwGLUTModifiersFunc(glutGetModifiers);

    // Create some 3D objects (stored in display lists)
    glNewList(1, GL_COMPILE);
    glBegin(GL_QUADS);
	glNormal3d(0, 0, 1);//front
	glVertex3f(-1.0f, 2.0f, 3.0f);//A
	glVertex3f(-1.0f, -2.0f, 3.0f);//B
	glVertex3f(1.0f, -2.0f, 3.0f);//C
	glVertex3f(1.0f, 2.0f, 3.0f);//D

	glNormal3d(0, 0, -1);//back
	glVertex3f(-1.0f, 2.0f, -3.0f);//E
	glVertex3f(1.0f, 2.0f, -3.0f);//H
	glVertex3f(1.0f, -2.0f, -3.0f);//G
	glVertex3f(-1.0f, -2.0f, -3.0f);//F

	glNormal3d(-1, 0, 0);//left
	glVertex3f(-1.0f, 2.0f, 3.0f);//A
	glVertex3f(-1.0f, 2.0f, -3.0f);//E
	glVertex3f(-1.0f, -2.0f, -3.0f);//F
	glVertex3f(-1.0f, -2.0f, 3.0f);//B

	glNormal3d(1, 0, 0);//right
	glVertex3f(1.0f, -2.0f, 3.0f);//C
	glVertex3f(1.0f, -2.0f, -3.0f);//G
	glVertex3f(1.0f, 2.0f, -3.0f);//H
	glVertex3f(1.0f, 2.0f, 3.0f);//D


	glNormal3d(0, 1, 0);//up
	glVertex3f(-1.0f, 2.0f, 3.0f);//A
	glVertex3f(1.0f, 2.0f, 3.0f);//D
	glVertex3f(1.0f, 2.0f, -3.0f);//H
	glVertex3f(-1.0f, 2.0f, -3.0f);//E

	glNormal3d(0, -1, 0);//down
	glVertex3f(-1.0f, -2.0f, 3.0f);//B
	glVertex3f(-1.0f, -2.0f, -3.0f);//F
	glVertex3f(1.0f, -2.0f, -3.0f);//G
	glVertex3f(1.0f, -2.0f, 3.0f);//C
	glEnd();
    glEndList();

	glNewList(2, GL_COMPILE);
	glBegin(GL_QUADS);
	glNormal3d(0, 0, 1);//front
	glVertex3f(-5.0f, 5.0f, -10.0f);//A
	glVertex3f(-5.0f, -5.0f, -10.0f);//B
	glVertex3f(5.0f, -5.0f, -10.0f);//C
	glVertex3f(5.0f, 5.0f, -10.0f);//D
	glEnd();

	glEndList();
	



    // Create a tweak bar
    bar = TwNewBar("TweakBar");
    TwDefine(" GLOBAL help='This example shows how to integrate AntTweakBar with GLUT and OpenGL.' "); // Message added to the help bar.
    TwDefine(" TweakBar size='200 400' color='96 216 224' "); // change default tweak bar size and color

    // Add 'g_Zoom' to 'bar': this is a modifable (RW) variable of type TW_TYPE_FLOAT. Its key shortcuts are [z] and [Z].
    TwAddVarRW(bar, "Zoom", TW_TYPE_FLOAT, &g_Zoom, 
               " min=-30 max=30 step=0.01 keyIncr=z keyDecr=Z help='Scale the object (1=original size).' ");

//     // Add 'g_Rotation' to 'bar': this is a variable of type TW_TYPE_QUAT4F which defines the object's orientation
//     TwAddVarRW(bar, "ObjRotation", TW_TYPE_QUAT4F, &g_Rotation, 
//                " label='Object rotation' opened=true help='Change the object orientation.' ");

	TwAddVarRW(bar, "AxisDir", TW_TYPE_DIR3F, &g_AxisDirection, 
               " label='Axis direction' opened=true help='Change the Axis direction.' ");

    // Add callback to toggle auto-rotate mode (callback functions are defined above).
    TwAddVarCB(bar, "AutoRotate", TW_TYPE_BOOL32, SetAutoRotateCB, GetAutoRotateCB, NULL, 
               " label='Auto-rotate' key=space help='Toggle auto-rotate mode.' ");

    // Add 'g_LightMultiplier' to 'bar': this is a variable of type TW_TYPE_FLOAT. Its key shortcuts are [+] and [-].
    TwAddVarRW(bar, "Multiplier", TW_TYPE_FLOAT, &g_LightMultiplier, 
               " label='Light booster' min=0.1 max=4 step=0.02 keyIncr='+' keyDecr='-' help='Increase/decrease the light power.' ");

    // Add 'g_LightDirection' to 'bar': this is a variable of type TW_TYPE_DIR3F which defines the light direction
    TwAddVarRW(bar, "LightDir", TW_TYPE_DIR3F, &g_LightDirection, 
               " label='Light direction' opened=true help='Change the light direction.' ");

    // Add 'g_MatAmbient' to 'bar': this is a variable of type TW_TYPE_COLOR3F (3 floats color, alpha is ignored)
    // and is inserted into a group named 'Material'.
    TwAddVarRW(bar, "Ambient", TW_TYPE_COLOR3F, &g_MatAmbient, " group='Material' ");

    // Add 'g_MatDiffuse' to 'bar': this is a variable of type TW_TYPE_COLOR3F (3 floats color, alpha is ignored)
    // and is inserted into group 'Material'.
    TwAddVarRW(bar, "Diffuse", TW_TYPE_COLOR3F, &g_MatDiffuse, " group='Material' ");


    // Store time8ioi88uiiii
    g_RotateTime = GetTimeMs();
    // Init rotation
    SetQuaternionFromAxisAngle(axis, angle, g_Rotation);
    SetQuaternionFromAxisAngle(axis, angle, g_RotateStart);

    // Call the GLUT main loop
    glutMainLoop();

    return 0;
}

