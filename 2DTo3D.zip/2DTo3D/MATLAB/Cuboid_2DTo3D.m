function F = Cuboid_2DTo3D(x)
Data = load('2D_data_CFAB.txt');
C_Prime = Data(1,:);
F_Prime = Data(2,:);
A_Prime = Data(3,:);
B_Prime = Data(4,:);

X_Prime = C_Prime - B_Prime;
Y_Prime = A_Prime - B_Prime;
Z_Prime = F_Prime - B_Prime;

% 1 sigma_1
% 2 sigma_2
% 3 sigma_3
% 4 axix_x
% 5 axix_y
% 6 axix_z
% 7 cos_theta
% 8 sin_theta



F(1) = x(1) * ( x(7) + ( 1 - x(7)) * x(4)^2) - X_Prime(1,1);
F(2) = x(2) * ( (1 - x(7)) * x(4) * x(5) - x(8) * x(6)) - Y_Prime(1,1);
F(3) = x(3) * ( (1 - x(7)) * x(4) * x(5) + x(8) * x(5)) - Z_Prime(1,1);
F(4) = x(1) * ( ( 1 - x(7)) * x(4) * x(5) + x(8) * x(6)) - X_Prime(1,2);
F(5) = x(2) * (  x(7) + (1 - x(7)) * x(5)^2) - Y_Prime(1,2);
F(6) = x(3) * ( (1 - x(7)) * x(5) * x(6) - x(8) * x(4)) - Z_Prime(1,2);
F(7) = x(7)^2 + x(8)^2 - 1;
F(8) = x(1) - 2;
F(9) = x(4)^2 + x(5)^2 + x(6)^2 - 1;




